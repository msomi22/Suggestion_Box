# flask-login

I am learning how to use flask by following a tutorial by Miguel Grinberg on Flask.I am trying to create a register and logging in  form using the following flask libraries

1. Flask

2. Flask-Login

3. Flask-SQLAlchemy

4. Flask-Wtf

